#!/bin/bash
# Under the terms of the GNU General Public License enclosed. See license file.
# Talk Calendar bash script uninstaller

echo "Uninstall Talk Calendar."
echo "This will remove Talk Calendar from your system."
read -p "Do you want to proceed? (yes/no) " yn

case $yn in 
	yes ) echo ok, uninstall will proceed;;
	no ) echo exiting...;
		exit;;
	* ) echo invalid response;
		exit 1;;
esac

DIR=/usr/bin/talkcalendar
if [ -d "$DIR" ]; then
  echo "$DIR exists"
    echo "Removing Talk Calendar."    
    sudo rm -r /usr/bin/talkcalendar
    sudo rm /usr/share/applications/org.gtk.talkcalendar.desktop    
else
	echo "Talk Calendar directory does not exist, exiting."
	exit
fi





