#!/bin/bash
# Under the terms of the GNU General Public License enclosed. See license file.
echo "Talk Calendar installer"
echo "This installer script assumes that the GTK4, SQLITE3 and ALSA base libraries are already installed which is the case for most modern GTK based distros (Ubuntu 24.04, Debian 13)."
echo "It also assumes that you are a member of the sudo group."
echo "You will need to use your sudo password."
echo "See Talk Calendar webpage for more information."
read -p "Do you want to proceed? (yes/no) " yn

case $yn in 
	yes ) echo ok, install will proceed;;
	no ) echo exiting installation;
		exit;;
	* ) echo invalid response;
		exit 1;;
esac

DIR=/usr/local/bin/talkcalendar
if [ ! -d "$DIR" ]; then
echo "Making install directory."
sudo mkdir /usr/bin/talkcalendar
fi

echo "Copying Talk Calendar to install directory."
sudo cp talkcalendar /usr/bin/talkcalendar
echo "Creating Talk Calendar desktop file."
# adding desktop file
cat > ./temp << "EOF"
[Desktop Entry]
Version=0.4.7
Type=Application
Name=Talk Calendar
Comment=GTK4 Talking Calendar
Exec=/usr/bin/talkcalendar/./talkcalendar
Icon=x-office-calendar-symbolic
Keywords=Calendar;Talk;
MimeType=text/calendar;
EOF
sudo cp ./temp /usr/share/applications/org.gtk.talkcalendar.desktop;rm ./temp



