#!/bin/bash
echo "Checking if Flite TTS library is installed on Debian and Ubuntu"
dpkg --status libflite1 &> /dev/null
if [ $? -eq 0 ]; then
    echo "Flite library: Already installed"
    else
    echo "Installing Flite library"
    sudo apt install -y libflite1
fi

