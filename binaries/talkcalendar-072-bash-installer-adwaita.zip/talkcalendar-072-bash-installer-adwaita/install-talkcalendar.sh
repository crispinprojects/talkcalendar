#!/bin/bash
# Define installation directories based on the user's home directory
LOCAL_BIN_DIR="$HOME/.local/talkcalendar"
LOCAL_APP_DIR="$HOME/.local/share/applications"

# Create the directories if they don't exist
mkdir -p "$LOCAL_BIN_DIR"
mkdir -p "$LOCAL_APP_DIR"

# Install the application files
echo "Installing Talk Calendar binaries to $LOCAL_BIN_DIR"
cp talkcalendar "$LOCAL_BIN_DIR"

# Create the .desktop file for the application
echo "Creating .desktop file in $LOCAL_APP_DIR"
cat > "$LOCAL_APP_DIR/org.gtk.talkcalendar.desktop" << EOF
[Desktop Entry]
Name=Talk Calendar
Comment=A talking calendar
Exec=$LOCAL_BIN_DIR/talkcalendar
Path=$LOCAL_BIN_DIR
Icon=x-office-calendar-symbolic
Terminal=false
Type=Application
Categories=Office;Calendar;
EOF

# Ensure the .desktop file is executable
chmod +x "$LOCAL_APP_DIR/org.gtk.talkcalendar.desktop"

echo "Installation complete. Talk Calendar is now available in your applications menu."
