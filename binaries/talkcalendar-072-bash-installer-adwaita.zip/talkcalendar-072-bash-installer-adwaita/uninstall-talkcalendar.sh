#!/bin/bash

# Define local installation directories
LOCAL_BIN_DIR="$HOME/.local/talkcalendar"
LOCAL_APP_DIR="$HOME/.local/share/applications"
DB_FILE="$HOME/talkcalendar.db"

echo "Uninstalling Talk Calendar..."

# Remove the binary files
echo "Removing binaries from $LOCAL_BIN_DIR..."
rm -f "$LOCAL_BIN_DIR/talkcalendar"

# Remove the desktop file
echo "Removing desktop file from $LOCAL_APP_DIR..."
rm -f "$LOCAL_APP_DIR/org.gtk.talkcalendar.desktop"

# Remove the database file
# echo "Removing database file ($DB_FILE)..."
rm -f "$LOCAL_BIN_DIR/talkcalendar.db"

rmdir "$LOCAL_BIN_DIR" 2>/dev/null
rmdir "$LOCAL_APP_DIR" 2>/dev/null

echo "Uninstall complete" 
